<?php

/*
Plugin Name: PT-PrimAapp Demo Import
Plugin URI: https://primatree.com
Description: Import PrimAapp Demo
Author: primatree
Author URI: https://primatree.com
License: GPL3
License URI: http://www.gnu.org/licenses/gpl.html
Text Domain: pt-PADEPRE
*/

// Block direct access to the main plugin file.
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/**
 * Main plugin class with initialization tasks.
 */
class PADEPRE_Plugin {
	/**
	 * Constructor for this class.
	 */
	public function __construct() {
		/**
		 * Display admin error message if PHP version is older than 5.3.2.
		 * Otherwise execute the main plugin class.
		 */
		if ( version_compare( phpversion(), '5.3.2', '<' ) ) {
			add_action( 'admin_notices', array( $this, 'old_php_admin_error_notice' ) );
		}
		else {
			// Set plugin constants.
			$this->set_plugin_constants();

			// Composer autoloader.
			require_once PT_PADEPRE_PATH . 'vendor/autoload.php';

			// Instantiate the main plugin class *Singleton*.
			$pt_one_click_demo_import = PADEPRE\PrimaAppDemoImport::get_instance();

			// Register WP CLI commands
			if ( defined( 'WP_CLI' ) && WP_CLI ) {
				WP_CLI::add_command( 'PADEPRE list', array( 'PADEPRE\WPCLICommands', 'list_predefined' ) );
				WP_CLI::add_command( 'PADEPRE import', array( 'PADEPRE\WPCLICommands', 'import' ) );
			}
		}
	}


	/**
	 * Display an admin error notice when PHP is older the version 5.3.2.
	 * Hook it to the 'admin_notices' action.
	 */
	public function old_php_admin_error_notice() {
		$message = sprintf( esc_html__( 'The %2$sPrimaApp Demo Import%3$s plugin requires %2$sPHP 5.3.2+%3$s to run properly. Please contact your hosting company and ask them to update the PHP version of your site to at least PHP 5.3.2.%4$s Your current version of PHP: %2$s%1$s%3$s', 'pt-PADEPRE' ), phpversion(), '<strong>', '</strong>', '<br>' );

		printf( '<div class="notice notice-error"><p>%1$s</p></div>', wp_kses_post( $message ) );
	}


	/**
	 * Set plugin constants.
	 *
	 * Path/URL to root of this plugin, with trailing slash and plugin version.
	 */
	private function set_plugin_constants() {
		// Path/URL to root of this plugin, with trailing slash.
		if ( ! defined( 'PT_PADEPRE_PATH' ) ) {
			define( 'PT_PADEPRE_PATH', plugin_dir_path( __FILE__ ) );
		}
		if ( ! defined( 'PT_PADEPRE_URL' ) ) {
			define( 'PT_PADEPRE_URL', plugin_dir_url( __FILE__ ) );
		}

		// Action hook to set the plugin version constant.
		add_action( 'admin_init', array( $this, 'set_plugin_version_constant' ) );
	}


	/**
	 * Set plugin version constant -> PT_PADEPRE_VERSION.
	 */
	public function set_plugin_version_constant() {
		if ( ! defined( 'PT_PADEPRE_VERSION' ) ) {
			$plugin_data = get_plugin_data( __FILE__ );
			define( 'PT_PADEPRE_VERSION', $plugin_data['Version'] );
		}
	}
}

// Instantiate the plugin class.
$PADEPRE_plugin = new PADEPRE_Plugin();



function PADEPRE_import_files() {
  return array(
    array(
      'import_file_name'           => 'PrimaApp Demo Import',
      'categories'                 => array( '' ),
      'import_file_url'            => 'https://primatree.com/themes/primaapp_demo_files/primaapp.xml',
      'import_widget_file_url'     => 'https://primatree.com/themes/primaapp_demo_files/primaapp.json',
      'import_customizer_file_url' => 'https://primatree.com/themes/primaapp_demo_files/primaapp.dat',
      'import_redux'               => array(
        array(
          'file_url'    => '',
          'option_name' => '',
        ),
      ),
      'import_preview_image_url'   => 'https://primatree.com/themes/primaapp_demo_files/ptdemo.png',
      'import_notice'              => '',
      'preview_url'                => 'https://primatree.com/',
    ),
  );
}
add_filter( 'pt-PADEPRE/import_files', 'PADEPRE_import_files' );

    // array(
    //   'import_file_name'           => 'Demo Import 2',
    //   'categories'                 => array( 'C1' ),
    //   'import_file_url'            => 'http://www.your_domain.com/PADEPRE/demo-content2.xml',
    //   'import_widget_file_url'     => 'http://www.your_domain.com/PADEPRE/widgets2.json',
    //   'import_customizer_file_url' => 'http://www.your_domain.com/PADEPRE/customizer2.dat',
    //   'import_redux'               => array(
    //     array(
    //       'file_url'    => 'http://www.your_domain.com/PADEPRE/redux.json',
    //       'option_name' => 'redux_option_name',
    //     ),
    //     array(
    //       'file_url'    => 'http://www.your_domain.com/PADEPRE/redux2.json',
    //       'option_name' => 'redux_option_name_2',
    //     ),
    //   ),
    //   'import_preview_image_url'   => 'http://www.your_domain.com/PADEPRE/preview_import_image2.jpg',
    //   'import_notice'              => __( 'A special note for this import.', 'your-textdomain' ),
    //   'preview_url'                => 'http://www.your_domain.com/my-demo-2',
    // ),


function PADEPRE_after_import_setup() {

		//set menues //
		$main_menu = get_term_by( 'name', 'Menu 1', 'nav_menu' );
		$footer_menu = get_term_by( 'name', 'Social menu', 'nav_menu' );

		set_theme_mod( 'nav_menu_locations', array(
				'primary' => $main_menu->term_id, // replace 'main-menu' here with the menu location identifier from register_nav_menu() function
				'footer_social' => $footer_menu->term_id, // replace 'main-menu' here with the menu location identifier from register_nav_menu() function
			)
		);

		//set front page//
		$frontp = get_page_by_title( 'Front Page' );  // add front page ID
		update_option( 'page_on_front', $frontp->ID );
		update_option( 'show_on_front', 'page' );
		//set blog page//
		$blog   = get_page_by_title( 'Blog' );   // add blog page ID
		update_option( 'page_for_posts', $blog->ID );
		
}
add_action( 'pt-PADEPRE/after_import', 'PADEPRE_after_import_setup' );