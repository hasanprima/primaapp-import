<?php
/**
 * The plugin page view - the "settings" page of the plugin.
 *
 * @package PADEPRE
 */

namespace PADEPRE;

$predefined_themes = $this->import_files;

if ( ! empty( $this->import_files ) && isset( $_GET['import-mode'] ) && 'manual' === $_GET['import-mode'] ) {
	$predefined_themes = array();
}

?>

<div class="PADEPRE  wrap  about-wrap">

	<?php ob_start(); ?>
		<h1 class="PADEPRE__title  dashicons-before"><?php esc_html_e( 'PrimaApp Demo Import', 'pt-PADEPRE' ); ?></h1>
	<?php
	$plugin_title = ob_get_clean();

	// Display the plugin title (can be replaced with custom title text through the filter below).
	echo wp_kses_post( apply_filters( 'pt-PADEPRE/plugin_page_title', $plugin_title ) );

	// Display warrning if PHP safe mode is enabled, since we wont be able to change the max_execution_time.
	if ( ini_get( 'safe_mode' ) ) {
		printf(
			esc_html__( '%sWarning: your server is using %sPHP safe mode%s. This means that you might experience server timeout errors.%s', 'pt-PADEPRE' ),
			'<div class="notice  notice-warning  is-dismissible"><p>',
			'<strong>',
			'</strong>',
			'</p></div>'
		);
	}

	// Start output buffer for displaying the plugin intro text.
	ob_start();
	?>

	<?php if(1==2){?>

	<div class="PADEPRE__intro-notice  notice  notice-warning  is-dismissible">
		<p><?php esc_html_e( 'Before you begin, make sure all the required plugins are activated.', 'pt-PADEPRE' ); ?></p>
	</div>

	<div class="PADEPRE__intro-text">
		<p class="about-description">
			<?php esc_html_e( 'Importing demo data (post, pages, images, theme settings, ...) is the easiest way to setup your theme.', 'pt-PADEPRE' ); ?>
			<?php esc_html_e( 'It will allow you to quickly edit everything instead of creating content from scratch.', 'pt-PADEPRE' ); ?>
		</p>

		<hr>

		<p><?php esc_html_e( 'When you import the data, the following things might happen:', 'pt-PADEPRE' ); ?></p>

		<ul>
			<li><?php esc_html_e( 'No existing posts, pages, categories, images, custom post types or any other data will be deleted or modified.', 'pt-PADEPRE' ); ?></li>
			<li><?php esc_html_e( 'Posts, pages, images, widgets, menus and other theme settings will get imported.', 'pt-PADEPRE' ); ?></li>
			<li><?php esc_html_e( 'Please click on the Import button only once and wait, it can take a couple of minutes.', 'pt-PADEPRE' ); ?></li>
		</ul>

		<?php if ( ! empty( $this->import_files ) ) : ?>
			<?php if ( empty( $_GET['import-mode'] ) || 'manual' !== $_GET['import-mode'] ) : ?>
				<a href="<?php echo esc_url( add_query_arg( array( 'page' => $this->plugin_page_setup['menu_slug'], 'import-mode' => 'manual' ), admin_url( $this->plugin_page_setup['parent_slug'] ) ) ); ?>" class="PADEPRE__import-mode-switch"><?php esc_html_e( 'Switch to manual import!', 'pt-PADEPRE' ); ?></a>
			<?php else : ?>
				<a href="<?php echo esc_url( add_query_arg( array( 'page' => $this->plugin_page_setup['menu_slug'] ), admin_url( $this->plugin_page_setup['parent_slug'] ) ) ); ?>" class="PADEPRE__import-mode-switch"><?php esc_html_e( 'Switch back to theme predefined imports!', 'pt-PADEPRE' ); ?></a>
			<?php endif; ?>
		<?php endif; ?>

		<hr>
	</div>

	<?php } ?>

	<?php
	$plugin_intro_text = ob_get_clean();

	// Display the plugin intro text (can be replaced with custom text through the filter below).
	echo wp_kses_post( apply_filters( 'pt-PADEPRE/plugin_intro_text', $plugin_intro_text ) );
	?>

	<?php if ( empty( $this->import_files ) ) : ?>
		<div class="notice  notice-info  is-dismissible">
			<p><?php esc_html_e( 'There are no predefined import files available in this theme. Please upload the import files manually!', 'pt-PADEPRE' ); ?></p>
		</div>
	<?php endif; ?>

	<?php if ( empty( $predefined_themes ) ) : ?>

		<div class="PADEPRE__file-upload-container">
			<h2><?php esc_html_e( 'Manual demo files upload', 'pt-PADEPRE' ); ?></h2>

			<div class="PADEPRE__file-upload">
				<h3><label for="content-file-upload"><?php esc_html_e( 'Choose a XML file for content import:', 'pt-PADEPRE' ); ?></label></h3>
				<input id="PADEPRE__content-file-upload" type="file" name="content-file-upload">
			</div>

			<div class="PADEPRE__file-upload">
				<h3><label for="widget-file-upload"><?php esc_html_e( 'Choose a WIE or JSON file for widget import:', 'pt-PADEPRE' ); ?></label></h3>
				<input id="PADEPRE__widget-file-upload" type="file" name="widget-file-upload">
			</div>

			<div class="PADEPRE__file-upload">
				<h3><label for="customizer-file-upload"><?php esc_html_e( 'Choose a DAT file for customizer import:', 'pt-PADEPRE' ); ?></label></h3>
				<input id="PADEPRE__customizer-file-upload" type="file" name="customizer-file-upload">
			</div>

			<?php if ( class_exists( 'ReduxFramework' ) ) : ?>
			<div class="PADEPRE__file-upload">
				<h3><label for="redux-file-upload"><?php esc_html_e( 'Choose a JSON file for Redux import:', 'pt-PADEPRE' ); ?></label></h3>
				<input id="PADEPRE__redux-file-upload" type="file" name="redux-file-upload">
				<div>
					<label for="redux-option-name" class="PADEPRE__redux-option-name-label"><?php esc_html_e( 'Enter the Redux option name:', 'pt-PADEPRE' ); ?></label>
					<input id="PADEPRE__redux-option-name" type="text" name="redux-option-name">
				</div>
			</div>
			<?php endif; ?>
		</div>

		<p class="PADEPRE__button-container">
			<button class="PADEPRE__button  button  button-hero  button-primary  js-PADEPRE-import-data"><?php esc_html_e( 'Import Demo Data', 'pt-PADEPRE' ); ?></button>
		</p>
<?php

		// $frontp = get_page_by_title( 'Front Page - PTD1' );
		// update_option( 'page_on_front', $frontp->ID );
		// update_option( 'show_on_front', 'page' );
		// //set blog page//
		// $blog   = get_page_by_title( 'Blog - PTD2' );
		// update_option( 'page_for_posts', $blog->ID );
		
?>
	<?php //elseif ( 1 === count( $predefined_themes ) ) : ?>
	<?php elseif ( 0 === count( $predefined_themes ) ) : ?>

		<div class="PADEPRE__demo-import-notice  js-PADEPRE-demo-import-notice"><?php
			if ( is_array( $predefined_themes ) && ! empty( $predefined_themes[0]['import_notice'] ) ) {
				echo wp_kses_post( $predefined_themes[0]['import_notice'] );
			}
		?></div>

		<p class="PADEPRE__button-container">
			<button class="PADEPRE__button  button  button-hero  button-primary  js-PADEPRE-import-data"><?php esc_html_e( 'Import Demo Data', 'pt-PADEPRE' ); ?></button>
		</p>

	<?php else : ?>

		<!-- PADEPRE grid layout -->
		<div class="PADEPRE__gl  js-PADEPRE-gl">
		<?php
			// Prepare navigation data.
			$categories = Helpers::get_all_demo_import_categories( $predefined_themes );
		?>
			<?php if(1==2){ if ( ! empty( $categories ) ) : ?>
				<div class="PADEPRE__gl-header  js-PADEPRE-gl-header">
					<nav class="PADEPRE__gl-navigation">
						<ul>
							<li class="active"><a href="#all" class="PADEPRE__gl-navigation-link  js-PADEPRE-nav-link"><?php esc_html_e( 'All', 'pt-PADEPRE' ); ?></a></li>
							<?php foreach ( $categories as $key => $name ) : ?>
								<li><a href="#<?php echo esc_attr( $key ); ?>" class="PADEPRE__gl-navigation-link  js-PADEPRE-nav-link"><?php echo esc_html( $name ); ?></a></li>
							<?php endforeach; ?>
						</ul>
					</nav>
					<div clas="PADEPRE__gl-search">
						<input type="search" class="PADEPRE__gl-search-input  js-PADEPRE-gl-search" name="PADEPRE-gl-search" value="" placeholder="<?php esc_html_e( 'Search demos...', 'pt-PADEPRE' ); ?>">
					</div>
				</div>
			<?php endif; }?>
			<br><br>
			<div class="PADEPRE__gl-item-container  wp-clearfix  js-PADEPRE-gl-item-container">
				<?php foreach ( $predefined_themes as $index => $import_file ) : ?>
					<?php
						// Prepare import item display data.
						$img_src = isset( $import_file['import_preview_image_url'] ) ? $import_file['import_preview_image_url'] : '';
						// Default to the theme screenshot, if a custom preview image is not defined.
						if ( empty( $img_src ) ) {
							$theme = wp_get_theme();
							$img_src = $theme->get_screenshot();
						}

					?>
					<div class="PADEPRE__gl-item js-PADEPRE-gl-item" data-categories="<?php echo esc_attr( Helpers::get_demo_import_item_categories( $import_file ) ); ?>" data-name="<?php echo esc_attr( strtolower( $import_file['import_file_name'] ) ); ?>">
						<div class="PADEPRE__gl-item-image-container">
							<?php if ( ! empty( $img_src ) ) : ?>
								<img class="PADEPRE__gl-item-image" src="<?php echo esc_url( $img_src ) ?>">
							<?php else : ?>
								<div class="PADEPRE__gl-item-image  PADEPRE__gl-item-image--no-image"><?php esc_html_e( 'No preview image.', 'pt-PADEPRE' ); ?></div>
							<?php endif; ?>
						</div>
						<div class="PADEPRE__gl-item-footer<?php echo ! empty( $import_file['preview_url'] ) ? '  PADEPRE__gl-item-footer--with-preview' : ''; ?>">
							<h4 class="PADEPRE__gl-item-title" title="<?php echo esc_attr( $import_file['import_file_name'] ); ?>"><?php echo esc_html( $import_file['import_file_name'] ); ?></h4>
							<button class="PADEPRE__gl-item-button  button  button-primary  js-PADEPRE-gl-import-data" value="<?php echo esc_attr( $index ); ?>"><?php esc_html_e( 'Import', 'pt-PADEPRE' ); ?></button>
							<?php if ( ! empty( $import_file['preview_url'] ) ) : ?>
								<a class="PADEPRE__gl-item-button  button" href="<?php echo esc_url( $import_file['preview_url'] ); ?>" target="_blank"><?php esc_html_e( 'Preview', 'pt-PADEPRE' ); ?></a>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div id="js-PADEPRE-modal-content"></div>

	<?php endif; ?>

	<p class="PADEPRE__ajax-loader  js-PADEPRE-ajax-loader">
		<span class="spinner"></span> <?php esc_html_e( 'Importing, please wait!', 'pt-PADEPRE' ); ?>
	</p>

	<div class="PADEPRE__response  js-PADEPRE-ajax-response"></div>
</div>
